# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the OpenTimelineIO project

# flake8: noqa

from . import (
    details_widget,
    timeline_widget,
)
